# git-practice
A website to show job openings and accept applications
